
/*
 * Auto generated Run-Time-Environment Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'Dma_sw_trigger_interrupt' 
 * Target:  'Dma_sw_trigger_interrupt' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "ARMCM0plus.h"



#endif /* RTE_COMPONENTS_H */
