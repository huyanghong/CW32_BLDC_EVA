
/******************************************************************************
 * Include files
 ******************************************************************************/
#include "main.h"
#include "cw32f030_gtim.h"
#include "cw32f030_gpio.h"
#include "cw32f030_rcc.h"
#include "cw32f030_flash.h"

/******************************************************************************
 * Local pre-processor symbols/macros ('#define')
 ******************************************************************************/
/******************************************************************************
 * Global variable definitions (declared in header file with 'extern')
 ******************************************************************************/

/******************************************************************************
 * Local type definitions ('typedef')
 ******************************************************************************/

/******************************************************************************
 * Local function prototypes ('static')
 ******************************************************************************/
void RCC_Configuration(void);
void GPIO_Configuration(void);
void NVIC_Configuration(void);

/******************************************************************************
 * Local variable definitions ('static')                                      *
 ******************************************************************************/

/******************************************************************************
 * Local pre-processor symbols/macros ('#define')
 ******************************************************************************/

/*****************************************************************************
 * Function implementation - global ('extern') and local ('static')
 ******************************************************************************/


/**
 ******************************************************************************
 ** \brief  Main function of project
 **
 ** \return uint32_t return value, if needed
 **
 ** This sample toggle GPIOA.00
 **
 ******************************************************************************/

/**
 * @brief  ʹ��HSI=48MHz��PCLK = 48M����Ƶ�ʴ���24M ��Ҫ����FlashWait=2��
 *         GTIM1��ʱ��48MHz ����, PA6��CH1����� SPWM
 *    
 * @return int32_t 
 */
int32_t main(void)
{
  GTIM_InitTypeDef GTIM_InitStruct; 
  
  /* System Clocks Configuration */
  RCC_Configuration();  

  RCC_AHBPeriphClk_Enable(RCC_AHB_PERIPH_FLASH , ENABLE);   // ��FLASHʱ��
  FLASH_SetLatency(FLASH_Latency_2);    // Ƶ�ʴ���24M��Ҫ����FlashWait=2
	RCC_HSI_Enable(RCC_HSIOSC_DIV1);     // �޸�HSI��ƵΪ1��PCLK = HSI

  /* GPIO Configuration */
  GPIO_Configuration();

  /* NVIC Configuration */
  NVIC_Configuration();  

  GTIM_InitStruct.Mode = GTIM_MODE_TIME;
  GTIM_InitStruct.OneShotMode = GTIM_COUNT_CONTINUE;
  GTIM_InitStruct.Prescaler = GTIM_PRESCALER_DIV1;
  //GTIM_InitStruct.ReloadValue = 60100UL >> 4;    // PWMƵ��Ϊ 48M/60100*16=12k, SPWMƵ�� = 12k/2/200=30Hz
  GTIM_InitStruct.ReloadValue = 60100UL;    // PWMƵ��Ϊ 48M/60100=800Hz, SPWM���� = 800/2/1000= 0.4Hz
  GTIM_InitStruct.ToggleOutState = DISABLE;

  GTIM_TimeBaseInit(CW_GTIM1, &GTIM_InitStruct);
  GTIM_OCInit(CW_GTIM1, GTIM_CHANNEL1, GTIM_OC_OUTPUT_PWM_HIGH);
  GTIM_SetCompare1(CW_GTIM1, 0);
  GTIM_ITConfig(CW_GTIM1, GTIM_IT_OV, ENABLE);

  GTIM_Cmd(CW_GTIM1, ENABLE); 
  
  while(1)
  {
    /* �жϷ�������interrupts_cw32f030.c */
  }
}

/**
  * @brief  Configures the different system clocks.
  * @param  None
  * @retval None
  */
void RCC_Configuration(void)
{
    CW_SYSCTRL->APBEN1_f.GTIM1 = 1U;    //
}

/**
  * @brief  Configure the GPIO Pins.
  * @param  None
  * @retval None
  */
void GPIO_Configuration(void)
{  
  /* PA6 PWM ��� */
  CW_SYSCTRL->AHBEN_f.GPIOA = 1UL; 
  CW_GPIOA->AFRL_f.AFR6 = 6; 
  CW_GPIOA->ANALOG = 0x00;    
  CW_GPIOA->DIR_f.PIN6 = 0;   
}

/**
  * @brief  Configure the nested vectored interrupt controller.
  * @param  None
  * @retval None
  */
void NVIC_Configuration(void)
{
  __disable_irq(); 
  NVIC_EnableIRQ(GTIM1_IRQn); 
  __enable_irq();  
}


/******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/
#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{ 
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

