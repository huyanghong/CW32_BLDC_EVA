
/*
 * Auto generated Run-Time-Environment Component Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'i2c_mcu_slave_poll' 
 * Target:  'i2c_mcu_slave_poll' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "ARMCM0plus.h"


#endif /* RTE_COMPONENTS_H */
