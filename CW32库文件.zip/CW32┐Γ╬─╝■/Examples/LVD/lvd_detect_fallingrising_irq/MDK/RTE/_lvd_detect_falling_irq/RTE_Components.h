
/*
 * Auto generated Run-Time-Environment Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'lvd_detect_falling_irq' 
 * Target:  'lvd_detect_falling_irq' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "ARMCM0plus.h"



#endif /* RTE_COMPONENTS_H */
