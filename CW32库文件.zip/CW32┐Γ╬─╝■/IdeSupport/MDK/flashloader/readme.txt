用于MDK工具的单片机Flash烧写配置文件，请将该文件拷贝到Keil的安装目录下。

1. 拷贝文件到Keil的安装路径：
    如Keil安装路径为C:\Program Files (x86)\Keil_v5
    则将FlashCW32F030.FLM拷贝到C:\Program Files (x86)\Keil_v5\ARM\Flash\文件中。

2. 使用：
    Keil界面->"Options for Target"->"Debug"->"Setting"->"Flash Download"->"Add"->在弹出的对话框中选择"CW32F030"->点击"Add","确定"
